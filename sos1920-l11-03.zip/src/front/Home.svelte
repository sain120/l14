<a href="#/gui1">GUI del recurso 1</a>
<a href="#/gui2">GUI del recurso 2</a>